﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenGL;
namespace OpenGLTutorial1
{
    class Reader
    {
        static List<Square> readFromFile(string filename)
        {
            List<Square> result = new List<Square>();
           
            var fileStream = new FileStream(filename, FileMode.Open, FileAccess.Read);
            using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
            {
                string line;
                streamReader.ReadLine();
                while ((line = streamReader.ReadLine()) != null)
                {
                    string[] args = line.Split(' ');
                    int.Parse(args[0]);

                    result.Add(new Square(1,1,1,new Vector3(1,1,1)));
                }
            }
            return result;
        }
    }
}
