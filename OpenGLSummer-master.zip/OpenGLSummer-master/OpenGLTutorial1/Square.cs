﻿using OpenGL;
using System;

namespace OpenGLTutorial1
{
    class Square
    {
        public float x, y;
        public Vector3 size;
        public Vector3 color;
        public Vector2 dirrection;
        static Random rnd = new Random();
        public Square(float x, float y, float size, Vector3 color)
        {
            this.x = x;
            this.y = y;
            this.size = new Vector3(size,size, 1);
            this.color = color;
            this.dirrection = new Vector2(rnd.Next(-255,256), rnd.Next(-255,256)).Normalize() ;
        }
    }
}
